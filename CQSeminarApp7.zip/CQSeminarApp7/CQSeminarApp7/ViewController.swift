//
//  ViewController.swift
//  CQSeminarApp7
//
//  Created by Minori Awamura on 2016/05/09.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var latitudeField: UITextField!
    @IBOutlet weak var longitudeField: UITextField!
    @IBOutlet weak var altitudeField: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // フィールド初期設定
        
        latitudeField.text = NSLocalizedString("LatitudeField", comment: "LatitudeField")
        longitudeField.text = NSLocalizedString("LongitudeField", comment: "LongitudeField")
        altitudeField.text = NSLocalizedString("AltitudeField", comment: "AltitudeField")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func actionMenuButton(_ sender: UIBarButtonItem) {
        
        // メニューアイテムローカライズ
        let actionMenuTitle = NSLocalizedString("ActionMenuTitle", comment: "ActionMenuTitle")
        let actionMenuMessage = NSLocalizedString("ActionMenuMessage", comment: "ActionMenuMessage")
        let actionMenuCancel = NSLocalizedString("ActionMenuCancel", comment: "ActionMenuCancel")
        let actionMenuMenu1 = NSLocalizedString("ActionMenuMenu1", comment: "ActionMenuMenu1")
        let actionMenuMenu2 = NSLocalizedString("ActionMenuMenu2", comment: "ActionMenuMenu2")
        
        // アクションメニュー
        let actionMenu = UIAlertController(title: actionMenuTitle, message: actionMenuMessage, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let cancelAction = UIAlertAction(title: actionMenuCancel, style: .cancel, handler: nil)
        let menu1Action = UIAlertAction(title: actionMenuMenu1, style: .default, handler: nil)
        let menu2Action = UIAlertAction(title: actionMenuMenu2, style: .default, handler: nil)
        
        actionMenu.addAction(cancelAction)
        actionMenu.addAction(menu1Action)
        actionMenu.addAction(menu2Action)
        
        present(actionMenu, animated: true, completion: nil)
    }
    

}

