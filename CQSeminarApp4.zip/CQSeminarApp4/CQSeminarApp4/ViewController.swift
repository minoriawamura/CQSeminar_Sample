//
//  ViewController.swift
//  CQSeminarApp4
//
//  Created by Minori Awamura on 2016/05/05.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate  {
    
    // Storyboard property
    
    @IBOutlet weak var compassArrow: UIImageView!
    
    @IBOutlet weak var idoValue: UILabel!
    @IBOutlet weak var keidoValue: UILabel!
    @IBOutlet weak var koudoValue: UILabel!
    @IBOutlet weak var houiValue: UILabel!
    
    // ロケーションマネージャ
    var locationManager = CLLocationManager()
    
    // 定数
    let labelMessage = "Unavailable"
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // ラベルを初期設定
        unavailabelLabel()
        
        // 位置情報利用許可のチェック
        locationManager.requestWhenInUseAuthorization()
        
        // デリゲート設定
        locationManager.delegate = self
        
        // ロケーション機能の設定
        // 精度設定
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        // 更新間隔
        locationManager.distanceFilter = 1.0    // 1.0m
        
        // コンパスの使用設定
        // デバイスの向きの設定（ポートレートが向いている方向）
        locationManager.headingOrientation = .portrait
        
        // 向きの更新角度
        locationManager.headingFilter = 1.0   // 1度
        
        // 向きの更新を開始
        locationManager.startUpdatingHeading()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // ラベルを、利用不可表示にする
    func  unavailabelLabel() {
        idoValue.text = labelMessage
        keidoValue.text = labelMessage
        koudoValue.text = labelMessage
        houiValue.text = labelMessage
    }

// CLLocationManager Delegate Method
    
    // 位置情報利用許可が変更になった時呼び出される
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        // 場合分け
        switch status {
        case .authorizedAlways :
            // ロケーションの更新開始
            locationManager.startUpdatingLocation()
        case .authorizedWhenInUse:
            // ロケーションの更新開始
            locationManager.startUpdatingLocation()
        case .notDetermined :
            // ロケーション更新を停止する
            locationManager.stopUpdatingLocation()
            unavailabelLabel()
            
        default:
            // ロケーションの更新を停止
            locationManager.stopUpdatingLocation()
            unavailabelLabel()
        }
    }
    
    // 位置が移動した時に呼ばれる
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // 位置配列の最後の値を取り出す。
        let lastLocation = locations.last
        
        // 緯度を表示
        guard let ido = lastLocation?.coordinate.latitude else {
           unavailabelLabel()
            
            return
        }
        
        idoValue.text = String(ido)
        
        // 経度を表示
        guard let keido = lastLocation?.coordinate.longitude else {
            unavailabelLabel()
            return
        }
        keidoValue.text = String(keido)
        
        guard let koudo = lastLocation?.altitude else {
            unavailabelLabel()
            return
        }
        koudoValue.text = String(koudo)
    }
    
    // 方角が変わった時呼ばれる
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        
        // 磁北の方向
        let kita = newHeading.magneticHeading
        
        // 磁北の方向に磁針を向ける
        compassArrow.transform = CGAffineTransform(rotationAngle: CGFloat(-kita * M_PI / 180))
        
        // デバイスの方位をラベル表示
        houiValue.text = String(kita)
    }
}

