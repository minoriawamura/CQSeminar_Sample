//
//  ViewController.swift
//  CQSeminarApp5
//
//  Created by Minori Awamura on 2016/05/05.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    // Storyboard Property
    
    // Map View
    @IBOutlet weak var mapScene: MKMapView!
    
    // Pin Button
    @IBOutlet weak var pinButton: UIBarButtonItem!
    
    // Map and Location
    
    var locationManager = CLLocationManager()
    var latestLocation: CLLocationCoordinate2D?
    
    // Camera Images
    var images = [UIImage]()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        // LocationManager 初期設定
        
        // Delegate 設定
        locationManager.delegate = self

        // Accuracy 100m
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        
        // 更新ステップ
        locationManager.distanceFilter = 100.0
        
        // 位置情報利用許可のチェック
        let status = CLLocationManager.authorizationStatus()
        
        if status == CLAuthorizationStatus.notDetermined {
            // 未認証ならリクエストダイアログ出す
            locationManager.requestWhenInUseAuthorization()
        }

        // 位置情報の取得開始
        locationManager.startUpdatingLocation()
        
        // mapView Delegate設定
        mapScene.delegate = self
 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tapPinButton(_ sender: UIBarButtonItem) {
        
        // カメラの状態を確認する
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            
            // 写真選択画面
            let mapImagePicker = UIImagePickerController()
            // カメラを選択
            mapImagePicker.sourceType = UIImagePickerControllerSourceType.camera
            // Delegate を設定
            mapImagePicker.delegate = self

            mapImagePicker.cameraDevice = UIImagePickerControllerCameraDevice.rear
            
            
            // 写真画面表示
            self.present(mapImagePicker, animated: true, completion: nil)
        }
        
    }
    
    // ImagePicker Delegate メソッド
    
    // 写真選択後に呼ばれる
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            
            // Camera Images配列に入れる
            images.append(pickedImage)
        }
        
        // 写真画面を閉じる
        picker.dismiss(animated: true, completion: nil)
        
        // 最後の位置情報を地図の真ん中にする
        let mapCenter = CLLocationCoordinate2DMake(latestLocation!.latitude, latestLocation!.longitude)
        
        // 最後の位置情報を地図の中心に設定
        mapScene.setCenter(mapCenter, animated: true)
        
        // ピンを作成する
        let centerPin = MKPointAnnotation()
        
        // 最後の位置情報をピンの位置に設定
        centerPin.coordinate = mapCenter
        
        // ピンにタイトルとサブタイトルを設定
        centerPin.title = "\(mapScene.annotations.count)"
        centerPin.subtitle = "\(latestLocation!.latitude), \(latestLocation!.longitude)"
        
        // 地図にピンを表示
        mapScene.addAnnotation(centerPin)
        
    }
    
    // 写真画面でキャンセルになったときに呼ばれる
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // 写真画面を閉じる
        picker.dismiss(animated: true, completion: nil)
    }
    
    // LocationManager Delegate メソッド
    
    // 位置情報が更新されたら呼ばれる
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // 位置情報の配列から最後のデータを取り出す
        latestLocation = locations.last?.coordinate
        
        if let loc = locations.last?.coordinate {
            latestLocation = loc
            
            // 最後の位置を中心に5km四方を表示
            let region = MKCoordinateRegionMakeWithDistance(latestLocation!, 5000, 5000)
            mapScene.setRegion(region, animated: true)
            
            // ピンボタンを有効に
            pinButton.isEnabled = true
            
        }
        
     }
    
    // 位置情報の利用許可が変更になったら呼ばれる
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status{
        case CLAuthorizationStatus.authorizedWhenInUse:
            // 位置情報の取得を開始させる
            locationManager.startUpdatingLocation()
        case CLAuthorizationStatus.authorizedAlways:
            // 位置情報の取得を開始させる
            locationManager.startUpdatingLocation()
        case CLAuthorizationStatus.denied:
            print("Denied")
        case CLAuthorizationStatus.restricted:
            print("Restricted")
        case CLAuthorizationStatus.notDetermined:
            print("NotDetermined")
        }
    }
    
    // MapView Delegate
    
    // ピンを表示するときに呼ばれる
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        
        // ピンのビューを作る
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        
        // サイズの設定
        let sizeOfPin = CGSize(width: 42, height: 42)
        
        // 写真をContext に描画
        UIGraphicsBeginImageContext(sizeOfPin)
        // 配列からイメージを取り出す
        images[Int(annotation.title!!)!].draw(in: CGRect(x: 0, y: 0, width: sizeOfPin.width, height: sizeOfPin.height))
        let annoImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        // ピンを表示
        annotationView.annotation = annotation
        
        // 写真をビューのイメージに設定
        annotationView.image = annoImage
        
        // 写真をタップしたら吹き出しを表示する
        annotationView.canShowCallout = true
        
        // 吹き出しに表示ボタンを設定する
        annotationView.rightCalloutAccessoryView = UIButton(type: UIButtonType.detailDisclosure)
        
        // ピンのビューを返す
        return annotationView
    }
    
    // 吹き出しをタップしたときに呼ばれる
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        // イメージ表示の画面に遷移する
        performSegue(withIdentifier: "showImageSegue", sender: view)
        
        // ピンを非選択にして吹き出しを消す
        mapScene.deselectAnnotation(view.annotation , animated: true)
    }
    
    // 画面遷移時の処理
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let id = segue.identifier {
            if id == "showImageSegue" {
                // タップしたピンのビュー
                let annotationView = sender as! MKAnnotationView
                // 遷移先のビューコントローラ
                let destVC = segue.destination as! CameraImageViewController
                destVC.imageFromPin = images[Int(annotationView.annotation!.title!!)!]
                
            }
        }
    }
    
    

}

