//
//  ViewController.swift
//  CQSeminarApp3
//
//  Created by Minori Awamura on 2016/05/02.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var pickedDate: UIDatePicker!

    
    var dailyTitle = ""
    var setDate = Date()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func changeDate(_ sender: UIDatePicker) {
        setDate = sender.date
    }

    @IBAction func nextButton(_ sender: UIButton) {
        
        dailyTitle = titleField.text!
        setDate = pickedDate.date
        
        if dailyTitle == "" {
            let alert = UIAlertController(title: "タイトル", message: "タイトルがありません", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            
        } else {
            
            performSegue(withIdentifier: "segueToDetail", sender: self)
        }
        
    }
    
    @IBAction func tapScreen(_ sender: UITapGestureRecognizer) {
        if titleField.isEditing {
            dailyTitle = titleField.text!
            titleField.endEditing(true)
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destVC = segue.destination as! DetailViewController
        
        destVC.titletext = dailyTitle
        destVC.setDate = setDate

        
    }
    
    
}

