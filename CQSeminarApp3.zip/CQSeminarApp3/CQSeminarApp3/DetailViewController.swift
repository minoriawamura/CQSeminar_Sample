//
//  DetailViewController.swift
//  CQSeminarApp3
//
//  Created by Minori Awamura on 2016/05/03.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var dateField: UITextField!
    
    @IBOutlet weak var bodyText: UITextView!
    
    var titletext: String = ""
    var setDate: Date = Date()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        titleField.text = titletext
        dateField.text = setDate.description
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func endEditing(_ sender: UITapGestureRecognizer) {
        bodyText.endEditing(true)
    }
    
    
    @IBAction func menuButton(_ sender: UIButton) {
        
        let actionMenu = UIAlertController(title: "Action", message: "Choose Action", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let saveAction = UIAlertAction(title: "Save", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction) -> Void in self.saveData()
                    })
        
        let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
            (action: UIAlertAction) -> Void in self.deleteData()
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil )
        
        actionMenu.addAction(saveAction)
        actionMenu.addAction(deleteAction)
        actionMenu.addAction(cancelAction)
        
        self.present(actionMenu, animated: true, completion: nil)
        
    }
    
    func saveData () {
        
        
        
    }
    
    func deleteData () {
        bodyText.text = ""
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }


}
